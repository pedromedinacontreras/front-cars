/**
*
* NewsItem
*
*/

import React, { PropTypes } from 'react';
import { isEmpty } from 'lodash';
import TextField from 'material-ui/TextField';
import CircularProgress from 'material-ui/CircularProgress';
import RaisedButton from 'material-ui/RaisedButton';
import Snackbar from 'material-ui/Snackbar';
import { graphql } from 'react-apollo';
import gql from 'graphql-tag';
import { PaperContainer, PaperTitle, Image, FlexRow, TextArea } from './StyledComponents';

const styles = {
  button: {
    marginTop: 16,
    alignSelf: 'flex-end',
  },
  progress: {
    alignSelf: 'flex-end',
  },
};

class NewsItem extends React.Component { // eslint-disable-line react/prefer-stateless-function
  constructor(props) {
    super(props);
    this.state = {
      loading: false,
      open: false,
      message: '',
      title: '',
      description: '',
      contenent: '',
      newsImage: '',
    };
  }
  handleChangeTitle = (event, title) => {
    this.setState({ title });
  }
  handleChangeDescription = (event, description) => {
    this.setState({ description });
  }
  handleChangeUrl = (event, url) => {
    this.setState({ newsImage: url });
  }
  handleChangeContent = (event) => {
    const contenent = event.target.value;
    this.setState({ contenent });
  }
  handleOnSave = () => {
    const { title, description, contenent, newsImage } = this.state;
    if (isEmpty(title) || isEmpty(description) || isEmpty(contenent) || isEmpty(newsImage)) {
      this.setState({ open: true, message: 'Todos los campos son requeridos' });
      return;
    }
    const { mutate } = this.props;
    const inputNew = {
      title,
      description,
      contenent,
      newsImage,
    };
    this.setState({ loading: true });
    mutate({ variables: { inputNew } }).then((res) => {
      console.log(res); // eslint-disable-line
      this.setState({
        loading: false,
        open: true,
        message: 'Guardado exitoso',
        title: '',
        description: '',
        contenent: '',
        newsImage: '',
      });
    }).catch((err) => {
      this.setState({ loading: false });
      console.log(err); // eslint-disable-line
    });
  }
  handleRequestClose = () => {
    this.setState({
      open: false,
    });
  };
  render() {
    const { loading, open, message, title, description, contenent, newsImage } = this.state;
    const loadingComponent = (
      <CircularProgress style={styles.progress} />
    );
    const button = (
      <RaisedButton label="Guardar" primary style={styles.button} onClick={this.handleOnSave} />
    );
    return (
      <PaperContainer>
        <Snackbar
          open={open}
          message={message}
          autoHideDuration={3000}
          onRequestClose={this.handleRequestClose}
        />
        <PaperTitle>Crear noticia</PaperTitle>
        <TextField
          style={{ width: '100%' }}
          hintText="Titulo"
          value={title}
          onChange={this.handleChangeTitle}
        />
        <TextField
          style={{ width: '100%' }}
          hintText="Descripción"
          value={description}
          onChange={this.handleChangeDescription}
        />
        <TextField
          style={{ width: '100%' }}
          hintText="Imagen URL"
          value={newsImage}
          onChange={this.handleChangeUrl}
        />
        <FlexRow>
          <Image src={this.state.newsImage} />
          <TextArea
            onChange={this.handleChangeContent}
            value={contenent}
          />
        </FlexRow>
        {loading ? loadingComponent : button}
      </PaperContainer>
    );
  }
}

NewsItem.propTypes = {
  mutate: PropTypes.func,
};

const addNewMutation = gql`
mutation AddNew($inputNew: NewInput!){
  AddNew(input: $inputNew){
    id
    createdAt
  }
}
`;

const NewsItemWithMutation = graphql(addNewMutation)(NewsItem);

export default NewsItemWithMutation;
