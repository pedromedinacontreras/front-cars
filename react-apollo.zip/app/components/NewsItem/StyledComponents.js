import styled from 'styled-components';
import Paper from 'material-ui/Paper';

export const PaperContainer = styled(Paper)`
  display: flex;
  flex-direction: column;
  width: 50%;
  height: 65%;
  padding: 16px;
  margin-top: 80px;
`;

export const PaperTitle = styled.div`
  font-family: Roboto;
  text-align: center;
  font-size: 20px;
  font-weight: 500;
  line-height: 1.4;
  color: rgba(0, 0, 0, 0.87);
`;

export const FlexRow = styled.div`
  margin-top: 32px;
  height: 80%;
  display: flex;
  flex-direction: row;
  justify-content: space-around;
`;

export const Image = styled.img`
  width: 50%;
  height: 100%;
`;

export const TextArea = styled.textarea`
  width: 45%;
  background-color: #eaeeee;
`;
